import React from "react";
import Users from "./Users";
import {link, useNavigate} from "react-router-dom";

function home(params) {
    let history =useNavigate();

    return(
        <div>
            <table >
                <thead>
                    <th>name</th>
                    <th>Email</th>
                    <th>Mobile No</th>
                    <th>Age</th>
                </thead>
                <tbody>
                    {
                        Users.map((item) =>{
                            <tr>
                                <td>{item.name}</td>
                                <td>{item.email}</td>
                                <td>{item.mobile}</td>
                                <td>{item.age}</td>
                                <td>
                                    <Link to={'/edit'}>
                                    <Button onclick={(e) => setID(item.name,item.mobile,item.email,item.age)}>
                                        Update  
                                    </Button>
                                    </Link>
                                </td>
                                <td>
                                    <Link to={'/edit'}>
                                    <Button onclick={(e) => deleted(item.id)}>
                                        Delete 
                                    </Button>
                                    </Link>
                                </td>
                            </tr>
                    })  
                }   
                </tbody>
            </table>
        </div>
    )
}