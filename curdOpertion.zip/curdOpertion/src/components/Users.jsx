const Users  =[
    {
        id:"1",
        name:"abi",
        mobile:"89627978",
        email:"738597",
        age:18
    },
    {
        id:"1",
        name:"abi",
        mobile:"89627978",
        email:"738597",
        age:18 
    },
    {
        id:"1",
        name:"abi",
        mobile:"89627978",
        email:"738597",
        age:18
    }
]
export default Users;